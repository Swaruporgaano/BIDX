# CYVRA BidX — Prototype Build

A working, click-through prototype of the CYVRA BidX reverse-auction marketplace
(Home Bid + Corporate Bid), built by CYVORIQ Solutions. This is a **frontend-only
demo**: everything works in the browser, but nothing is saved to a real server —
there's no backend yet. Read "What's real vs. what's simulated" below before you
show this to anyone important.

## The fastest way to see it

You don't need to build anything. Open **`dist/index.html`** in a browser, or serve
the `dist` folder with any static file server:

```bash
npx serve dist
```

Then open the URL it gives you (usually `http://localhost:3000`).

## Deploying it for real (recommended: Netlify or Vercel, both free)

**Netlify (easiest — no command line needed):**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag the `dist` folder onto the page
3. You get a live URL in about 10 seconds

**Vercel:**
```bash
npm install -g vercel
cd dist
vercel --prod
```

**Your own hosting / cPanel / cyvoriq.com:**
Just upload the three files inside `dist/` (`index.html`, `bundle.js`, `styles.css`)
to your web server's public folder (e.g. `public_html/bidx/`). No server-side code,
no database, no special configuration needed — it's a fully static site.

Once it's live, point a subdomain like `bidx.cyvoriq.com` at it via your domain
registrar's DNS settings (a CNAME record to Netlify/Vercel, or an A record if
self-hosting).

## Making changes / rebuilding

The actual editable source is in `src/App.jsx` — one file, the whole app. To change
something and rebuild:

```bash
npm install        # first time only
npm run build       # rebuilds dist/bundle.js and dist/styles.css
```

If you don't code, hand this project (this whole folder) to a developer or to
Claude Code — `src/App.jsx` is plain, readable React with comments marking each
section (nav, home pages, browse, listing detail, sell flow, wallet, dashboard).

## Project structure

```
cyvra-site/
├── src/
│   ├── App.jsx        ← the entire app (components, data, logic)
│   ├── main.jsx        ← 3 lines, just mounts App into the page
│   └── input.css       ← Tailwind entry point
├── dist/                ← BUILD OUTPUT — this is what you deploy
│   ├── index.html
│   ├── bundle.js        ← React + Three.js + the app, bundled and minified
│   └── styles.css
├── package.json
└── tailwind.config.js
```

## What's real vs. what's simulated

This prototype is meant to prove out the **user experience and business logic**,
not to be a production system yet. Specifically:

| Feature | Status |
|---|---|
| Browsing, bidding, listings, filters, sorting | Fully working (in-memory, resets on page reload) |
| CYVRA TEST / CYVRA DELETE checkpoint flow | Simulated — no real device-scanning app exists yet |
| Photo & video upload | **Real** — actual files you pick are read and previewed in-browser |
| 25-point verification report | Real UI, illustrative data |
| Wallet & "Add Money" | Simulated — no real payment processor connected |
| Escrow | Not implemented — this is explicitly called out in the UI; real fund custody requires a licensed Payment Aggregator integration (Razorpay/Cashfree Route or similar) |
| Accounts / login | Not implemented — anyone who opens the link is "you" for that session |
| Data persistence | None — refreshing the page resets everything |

## Suggested next engineering steps, in order

1. **Backend + database** (Supabase or Firebase free tier is the fastest path) for
   real accounts, persistent listings and bids.
2. **Payment Aggregator escrow integration** (Razorpay Route / Cashfree Easy Split)
   to replace the demo wallet with real fund custody — this is a business/compliance
   step as much as an engineering one (needs your PA merchant agreement in place).
3. **Real device-diagnostic app** for CYVRA TEST / CYVRA DELETE, or a partnership /
   licensing deal with an existing diagnostic SDK, since building a cross-platform
   (Windows/macOS/Android) hardware diagnostic tool is a substantial project on its
   own — bigger than the marketplace itself, and worth scoping separately.
4. **IMEI/CEIR blacklist API** access for the mobile verification step.

## Tech stack

React 18, Three.js (hero animation only, wrapped in an error boundary so it fails
safely if WebGL isn't available), Tailwind CSS (compiled at build time, not the
runtime CDN version), lucide-react icons. No frameworks beyond that — no Next.js,
no router library, just plain React state for navigation. Bundled with esbuild.
